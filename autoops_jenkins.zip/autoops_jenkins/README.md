# autoops_jenkins
以go语言为主的autoops_jenkins写法

技术栈
- gin
- gorm
- mysql
- redis
- kafka
- dockerfile


# autoops_jenkins
